# WPGraphQL Admin

This directory is intended to include admin UI such as WPGraphQL Settings pages, GraphiQL, etc. 
